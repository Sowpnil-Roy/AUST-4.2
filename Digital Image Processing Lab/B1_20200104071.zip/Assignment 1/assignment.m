img_happy = imread("happy_image.png");
img_sad = imread("sad_image.png");
img_angry = imread("angry_image.png");

targetSize = [400, 600];
img_happy = imresize(img_happy, targetSize);
img_sad = imresize(img_sad, targetSize);
img_angry = imresize(img_angry, targetSize);

gray_img_happy = rgb2gray(img_happy);
gray_img_sad = rgb2gray(img_sad);
gray_img_angry = rgb2gray(img_angry);

[numRows, numCols] = size(gray_img_happy); 
numColumns = 3; 

columns_happy = cell(1, numColumns);
columns_sad = cell(1, numColumns);
columns_angry = cell(1, numColumns);

columnWidth = floor(numCols / numColumns);

for i = 1:numColumns
    startCol = (i - 1) * columnWidth + 1;
    endCol = i * columnWidth;
    
    columns_happy{i} = gray_img_happy(:, startCol:endCol);
    
    columns_sad{i} = gray_img_sad(:, startCol:endCol);
    
    columns_angry{i} = gray_img_angry(:, startCol:endCol);
end

merged_image = [columns_happy{1}, columns_sad{2}, columns_angry{3}];

imwrite(merged_image, 'merged_image.png');
imshow(merged_image);

disp('Merged image saved successfully.');
